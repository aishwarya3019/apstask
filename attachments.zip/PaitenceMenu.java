package com.apstaks.main;

import java.sql.SQLException;
import java.util.Scanner;

public class PaitenceMenu {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		int id, pincode, n,p;
		String name, email, address, state, city, date, password;
		Long phone;
		boolean x = false;
		do {
			System.out.println("Enter Above Mention Option: ");
			System.out.println("1. Create Account");
			System.out.println("2. Login");
			System.out.println("3. Admin");
			System.out.println("4. AdminLogin");
			System.out.println("5. Logout");
			Scanner sc = new Scanner(System.in);
			n = sc.nextInt();
			switch (n) {
			case 1:
				System.out.println("1. Profile Creation");
				System.out.println("Enter Name");
				name = sc.next();
				System.out.println("Enter Phone");
				phone = sc.nextLong();
				System.out.println("Enter Email");
				email = sc.next();
				System.out.println("Enter Address");
				address = sc.next();
				System.out.println("Enter State");
				state = sc.next();
				System.out.println("Enter City");
				city = sc.next();
				System.out.println("Enter Pincode");
				pincode = sc.nextInt();
				System.out.println("Enter Date");
				date = sc.next();
				System.out.println("Enter Password");
				password = sc.next();
				PInsert insert = new PInsert(name, phone, email,address,state,city,pincode,date,password);
				x = true;
				break;
				
			case 2:
				System.out.println("Enter Email");
				email = sc.next();
				System.out.println("Enter Password");
				password = sc.next();
				Login login = new Login(email, password);
				
				x = true;
				break;
			case 3:
				System.out.println("Enter name for admin");
				 String user = sc.next();
				System.out.println("Enter Email for admin");
				 String aemail = sc.next();
				System.out.println("Enter Password for admin");
				String apassword = sc.next();
				Admin admin = new Admin(user, aemail, apassword);
				
				x = true;
				break;
			case 4:
				System.out.println("Admin Login");
				System.out.println("Enter Email");
				aemail = sc.next();
				System.out.println("Enter Password");
				apassword = sc.next();
				AdminLogin adminlogin = new AdminLogin(aemail, apassword);
				
				x = true;
				break;
				
			case 5:
				x = true;
				break;

				default:
					break;
				
				
			}
			
			

		} while (x != false);
		}
	}