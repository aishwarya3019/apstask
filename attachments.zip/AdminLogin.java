package com.apstaks.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.apstask.util.DbConnection;

public class AdminLogin {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	int z;

	AdminLogin(String aemail, String apassword) throws ClassNotFoundException, SQLException {
		con = DbConnection.GetConnection();
		String sql = "select * from admin where aemail=? and apassword=? ";
		pst = con.prepareStatement(sql);
		pst.setString(1, aemail);
		pst.setString(2, apassword);
		rs = pst.executeQuery();
		if (rs.next()) {

			System.out.println("1. Create User");
			System.out.println("2. Logout");

			Scanner sc = new Scanner(System.in);
			z = sc.nextInt();
			switch (z) {
			case 1:
				System.out.println("Enter name for admin");
				 String user = sc.next();
				System.out.println("Enter Email for admin");
				 aemail = sc.next();
				System.out.println("Enter Password for admin");
				apassword = sc.next();
				User u = new User(user, aemail, apassword);
				
				break;

			case 2:

				break;
			default:
				break;
			}
		} else

		{
			System.out.println("Invalid User");
		}
		rs.close();
		con.close();
	}
}
