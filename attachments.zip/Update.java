package com.apstaks.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.apstask.util.DbConnection;

public class Update {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;

	Update(String name, String city, Long num, int id) throws ClassNotFoundException, SQLException {
		String sql = "update hsp set name=?,city=?,num=? where id=?";
		con = DbConnection.GetConnection();
		pst = con.prepareStatement(sql);
		pst.setString(1, name);
		pst.setString(2, city);
		pst.setLong(3, num);
		pst.setInt(4, id);
		pst.executeUpdate();
		System.out.println("Updation Done");
		con.close();
	}
}
