package com.apstaks.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.apstask.util.DbConnection;

public class PInsert {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;

	PInsert(String name, Long phone, String email,String address,String state,String city,int pincode,String date,String password) throws ClassNotFoundException, SQLException {
	con = DbConnection.GetConnection();
	String sql = "insert into paitence(name,phone,email,address,state,city,pincode,date,password)values(?,?,?,?,?,?,?,?,?)";
	 pst = con.prepareStatement(sql);
	 pst.setString(1,name);
	 pst.setLong(2,phone);
	 pst.setString(3,email);
	 pst.setString(4,address);
	 pst.setString(5,state);
	 pst.setString(6,city);
	 pst.setInt(7,pincode);
	 pst.setString(8,date);
	 pst.setString(9,password);
	 pst.execute();
	 System.out.println("Successfull Created");
	 con.close();
	 
	}
}
