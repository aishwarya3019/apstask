package com.apstaks.main;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.apstask.util.DbConnection;
public class Delete {
	Connection con;
	PreparedStatement pst;
	Delete(int id) throws ClassNotFoundException, SQLException {
		con = DbConnection.GetConnection();
		String sql = "delete from hsp where id=?";
		pst = con.prepareStatement(sql);
		pst.setInt(1, id);
		pst.execute();
		pst.executeUpdate();
		System.out.println("Deletion Done");
		con.close();
	}
}
