package com.apstaks.main;

import java.sql.Connection;

import com.apstask.util.DbConnection;

public class Test {

	public static void main(String[] args) {
		try {
			Connection con = DbConnection.GetConnection();
			System.out.println(con);
		}catch (Exception e) {
			// TODO: handle exception
		}

	}

}
